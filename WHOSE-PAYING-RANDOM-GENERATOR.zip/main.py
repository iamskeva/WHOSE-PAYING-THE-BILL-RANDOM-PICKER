import random

#Generate seed key
testSeed = int(input("Create a seed number: "))
random.seed(testSeed)
#List the names of everyone
names_string = input("Give me everybody's names, separated by a comma. ")
names = names_string.split(", ")

#The number of persons that went out to eat
noOfPersons = len(names) -1

#Generating The random person to pay the bills
randonNumber = random.randint(0, noOfPersons)
randomChoice = names[randonNumber]

print(f"{randomChoice} is paying our bills for today.")
# print(random.choice(names))

